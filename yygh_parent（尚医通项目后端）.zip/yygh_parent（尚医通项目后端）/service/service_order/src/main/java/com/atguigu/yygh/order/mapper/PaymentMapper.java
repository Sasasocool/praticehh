package com.atguigu.yygh.order.mapper;

import com.atguigu.yygh.model.order.PaymentInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author lijian
 * @create 2021-05-05 9:13
 */
public interface PaymentMapper extends BaseMapper<PaymentInfo> {
}
