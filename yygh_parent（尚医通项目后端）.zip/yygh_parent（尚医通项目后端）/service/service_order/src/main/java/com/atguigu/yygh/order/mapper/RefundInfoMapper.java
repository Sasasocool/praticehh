package com.atguigu.yygh.order.mapper;

import com.atguigu.yygh.model.order.RefundInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author lijian
 * @create 2021-05-05 11:48
 */

//退款
public interface RefundInfoMapper extends BaseMapper<RefundInfo> {
}
