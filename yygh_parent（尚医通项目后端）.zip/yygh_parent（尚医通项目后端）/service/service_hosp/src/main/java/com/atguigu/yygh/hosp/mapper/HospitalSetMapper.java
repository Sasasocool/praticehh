package com.atguigu.yygh.hosp.mapper;

import com.atguigu.yygh.model.hosp.HospitalSet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * @author lijian
 * @create 2021-04-22 15:45
 */
public interface HospitalSetMapper extends BaseMapper<HospitalSet> {

}
