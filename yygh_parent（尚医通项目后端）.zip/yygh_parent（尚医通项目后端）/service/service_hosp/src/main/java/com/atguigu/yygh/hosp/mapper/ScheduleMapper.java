package com.atguigu.yygh.hosp.mapper;

import com.atguigu.yygh.model.hosp.Schedule;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author lijian
 * @create 2021-05-03 22:36
 */
public interface ScheduleMapper extends BaseMapper<Schedule> {
}
