package com.atguigu.yygh.user.mapper;

import com.atguigu.yygh.model.user.Patient;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author lijian
 * @create 2021-05-02 16:03
 */
public interface PatientMapper extends BaseMapper<Patient> {
}
